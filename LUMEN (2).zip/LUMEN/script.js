// Data from SubscriptionUseCase_Dataset.xlsx - Subscription_Plans.csv
const allPlans = [
    { "Product Id": 1, "Name": "Plan1", "Price": 57.65, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 2, "Name": "Plan2", "Price": 15.3, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 3, "Name": "Plan3", "Price": 73.86, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 4, "Name": "Plan4", "Price": 27.82, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 5, "Name": "Plan5", "Price": 42.58, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 6, "Name": "Plan6", "Price": 95.36, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 7, "Name": "Plan7", "Price": 23.3, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 8, "Name": "Plan8", "Price": 86.42, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 9, "Name": "Plan9", "Price": 96.42, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 10, "Name": "Plan10", "Price": 29.92, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 11, "Name": "Plan11", "Price": 60.47, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 12, "Name": "Plan12", "Price": 73.63, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 13, "Name": "Plan13", "Price": 22.09, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 14, "Name": "Plan14", "Price": 93.24, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 15, "Name": "Plan15", "Price": 59.41, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 16, "Name": "Plan16", "Price": 64.91, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 17, "Name": "Plan17", "Price": 60.8, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 18, "Name": "Plan18", "Price": 95.51, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 19, "Name": "Plan19", "Price": 14.69, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 20, "Name": "Plan20", "Price": 85.62, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 21, "Name": "Plan21", "Price": 58.3, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 22, "Name": "Plan22", "Price": 72.82, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 23, "Name": "Plan23", "Price": 82.02, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 24, "Name": "Plan24", "Price": 30.87, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 25, "Name": "Plan25", "Price": 86.13, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 26, "Name": "Plan26", "Price": 58.89, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 27, "Name": "Plan27", "Price": 88.67, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 28, "Name": "Plan28", "Price": 81.54, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 29, "Name": "Plan29", "Price": 32.18, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 30, "Name": "Plan30", "Price": 37.03, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 31, "Name": "Plan31", "Price": 57.73, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 32, "Name": "Plan32", "Price": 41.16, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 33, "Name": "Plan33", "Price": 72.32, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 34, "Name": "Plan34", "Price": 29.63, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 35, "Name": "Plan35", "Price": 95.92, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 36, "Name": "Plan36", "Price": 55.52, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 37, "Name": "Plan37", "Price": 75.17, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 38, "Name": "Plan38", "Price": 91.24, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 39, "Name": "Plan39", "Price": 73.79, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 40, "Name": "Plan40", "Price": 14.24, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 41, "Name": "Plan41", "Price": 74.2, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 42, "Name": "Plan42", "Price": 56.18, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 43, "Name": "Plan43", "Price": 73.76, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 44, "Name": "Plan44", "Price": 90.04, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 45, "Name": "Plan45", "Price": 75.29, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 46, "Name": "Plan46", "Price": 40.45, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 47, "Name": "Plan47", "Price": 28.49, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 48, "Name": "Plan48", "Price": 77.62, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 49, "Name": "Plan49", "Price": 23.95, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 50, "Name": "Plan50", "Price": 98.71, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 51, "Name": "Plan51", "Price": 96.48, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 52, "Name": "Plan52", "Price": 61.25, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 53, "Name": "Plan53", "Price": 49.65, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 54, "Name": "Plan54", "Price": 98.55, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 55, "Name": "Plan55", "Price": 85.94, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 56, "Name": "Plan56", "Price": 80.67, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 57, "Name": "Plan57", "Price": 84.09, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 58, "Name": "Plan58", "Price": 73.32, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 59, "Name": "Plan59", "Price": 44.15, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 60, "Name": "Plan60", "Price": 35.08, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 61, "Name": "Plan61", "Price": 89.64, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 62, "Name": "Plan62", "Price": 92.8, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 63, "Name": "Plan63", "Price": 74.74, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 64, "Name": "Plan64", "Price": 98.6, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 65, "Name": "Plan65", "Price": 29.87, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 66, "Name": "Plan66", "Price": 32.31, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 67, "Name": "Plan67", "Price": 49.96, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 68, "Name": "Plan68", "Price": 64.74, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 69, "Name": "Plan69", "Price": 21.23, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 70, "Name": "Plan70", "Price": 76.37, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 71, "Name": "Plan71", "Price": 87.83, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 72, "Name": "Plan72", "Price": 84.78, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 73, "Name": "Plan73", "Price": 61.59, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 74, "Name": "Plan74", "Price": 70.47, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 75, "Name": "Plan75", "Price": 69.17, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 76, "Name": "Plan76", "Price": 68.38, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 77, "Name": "Plan77", "Price": 28.3, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 78, "Name": "Plan78", "Price": 57.75, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 79, "Name": "Plan79", "Price": 98.68, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 80, "Name": "Plan80", "Price": 97.08, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 81, "Name": "Plan81", "Price": 22.61, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 82, "Name": "Plan82", "Price": 49.14, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 83, "Name": "Plan83", "Price": 13.99, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 84, "Name": "Plan84", "Price": 27.18, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 85, "Name": "Plan85", "Price": 85.72, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 86, "Name": "Plan86", "Price": 79.84, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 87, "Name": "Plan87", "Price": 31.29, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 88, "Name": "Plan88", "Price": 60.31, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 89, "Name": "Plan89", "Price": 73.32, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 90, "Name": "Plan90", "Price": 84.92, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 91, "Name": "Plan91", "Price": 43.65, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 92, "Name": "Plan92", "Price": 70.16, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 93, "Name": "Plan93", "Price": 43.4, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 94, "Name": "Plan94", "Price": 56.62, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 95, "Name": "Plan95", "Price": 16.35, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 96, "Name": "Plan96", "Price": 23.86, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 97, "Name": "Plan97", "Price": 89.7, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 98, "Name": "Plan98", "Price": 24.65, "Auto Renewal Allowed": "Yes", "Status": "Active" },
    { "Product Id": 99, "Name": "Plan99", "Price": 45.57, "Auto Renewal Allowed": "No", "Status": "Active" },
    { "Product Id": 100, "Name": "Plan100", "Price": 40.54, "Auto Renewal Allowed": "Yes", "Status": "Active" }
];

const plansContainer = document.getElementById('plans-container');
const searchInput = document.getElementById('search-input');
const editModal = document.getElementById('edit-modal');
const modalPlanDetails = document.getElementById('modal-plan-details');
const closeModalBtn = document.querySelector('.close-btn');

// Define the SVG code as a string
const lumenSvg = `<svg class="modal-logo-svg" viewBox="0 0 145 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M0 1.4332C0 .61497895.65465263.00138947 1.55466316.00138947c.94108421 0 1.55466316.61358948 1.55466316 1.43181053v14.1059263c0 .4910737.2046421.7364421.7364421.7364421H17.0602316c1.0639368 0 1.6775158.4910737 1.6775158 1.4318105 0 .9821369-.613579 1.4321474-1.6775158 1.4321474H1.67751579C.57286316 19.1395263 0 18.6895263 0 17.7073789V1.4332zm26.4292842 10.5716737c0 5.2775789 2.8639579 4.639021 8.0597474 4.639021 5.1957895 0 8.0597473.7203579 8.0597473-4.6390105V1.43330526c0-.81822105.6135895-1.4321579 1.5546632-1.4321579.9407368 0 1.5546632.61392632 1.5546632 1.4321579V12.2913053c0 6.5868736-4.0914737 7.3390526-11.1690737 7.3390526-7.0779474 0-11.1690737-.752179-11.1690737-7.3390526V1.43329474c0-.81822106.6135895-1.43214737 1.5546632-1.43214737.9410736 0 1.5546631.61391579 1.5546631 1.43214737V12.0048737zm49.5442421-7.21691581h-.1228631l-7.5276106 7.13509471c-.7579894.6447263-1.1114947 1.1864421-1.8003684 1.1864421-.5482316 0-1.0783053-.5194736-1.7589684-1.1864421l-7.5690105-7.17615786h-.163579V17.9531579c0 .8589474-.6135895 1.4318105-1.5546631 1.4318105-.9000106 0-1.5546632-.5728631-1.5546632-1.4318105V2.12864211C53.9218.9422 55.0165368.00111579 55.9264737.00111579c.9102842 0 1.6823158.54822105 2.7003895 1.59572632l7.9368947 7.78974736h.0407263l7.9372316-7.83081052C75.5772526.60853685 76.0488105.00111579 77.1189053.00111579c1.1296421 0 1.9639473.94108421 1.9639473 2.12752632V17.9531474c0 .8589473-.6135789 1.431821-1.5546631 1.431821-.9000106 0-1.5546632-.5728737-1.5546632-1.431821V4.78795789zm11.4553369 3.53818948l13.3373048.0376421c1.104653 0 1.677516.5318 1.677516 1.43181053 0 .9410737-.572863 1.4321474-1.677516 1.4321474H90.5381789v4.3115158c0 .4907368.2046422.7364421.7364422.7364421h13.5419679c1.06359 0 1.636453.4907263 1.636453 1.4318105 0 .9818-.572863 1.4318105-1.636453 1.4318105H89.1063789c-1.1046526 0-1.6775157-.4500105-1.6775157-1.4318105V8.32614737zm48.6445048 9.21771583c0 1.0636-.816863 1.8411052-1.88181 1.8411052-1.055716 0-1.762726-.8117263-2.782179-1.6775158L116.190242 4.62438947V17.9531579c0 .8182316-.613926 1.4318105-1.554663 1.4318105-.900347 0-1.554663-.6135895-1.554663-1.4318105V2.12864211c0-1.39108421.731305-2.12752632 1.840747-2.12752632 1.011242 0 1.600526.66628421 2.659316 1.55466316l15.383053 12.91983155V1.43327368c0-.81822105.613589-1.4321579 1.554663-1.4321579.900021 0 1.554673.61392632 1.554673 1.4321579V17.5438632zm2.167569-14.93333688v-.01413685c0-1.34223158 1.088147-2.47245263 2.458484-2.47245263 1.384842 0 2.458484 1.11607369 2.458484 2.45830527v.01414736c0 1.34223158-1.087789 2.47262106-2.458484 2.47262106-1.384495 0-2.458484-1.11625264-2.458484-2.45848421zm4.6344-.01413685v-.01414736c0-1.20094737-.932537-2.18989474-2.175916-2.18989474-1.229232 0-2.175916 1.00309474-2.175916 2.2040421v.01413685c0 1.20094736.932537 2.19006315 2.175916 2.19006315 1.229242 0 2.175916-1.00325263 2.175916-2.2042zm-3.136748-1.2998h1.130569c.550968 0 .960821.26841053.960821.79126316 0 .40968421-.240463.6639579-.57959.7628l.664127.94668421h-.579253l-.59341-.86181052h-.522674v.86181052h-.48059V1.29658947zm1.088137 1.24338948c.325 0 .508537-.16956842.508537-.40986316 0-.26841053-.183537-.40968421-.508537-.40968421h-.607537v.81954737h.607537z" fill="#000"></path>
    <path d="M106.330232 1.71966316c0-.94108421-.572874-1.47287369-1.677516-1.47287369H89.1060842c-1.1043263 0-1.6771789.53178948-1.6771789 1.47287369v1.42565263l17.2648737-.0345579c1.063579-.00001052 1.636453-.49107368 1.636453-1.39109473" fill="#0C9ED9"></path>
</svg>`;

// Function to open the modal
function openModal() {
    editModal.style.display = 'block';
}

// Function to close the modal
function closeModal() {
    editModal.style.display = 'none';
}

// Function to create and render a single card
function createCard(plan) {
    const card = document.createElement('div');
    card.classList.add('card');

    card.innerHTML = `
        <div class="card-header">
            <h3>${plan.Name}</h3>
        </div>
        <div class="card-body">
            <div class="price">
                <p>$${plan.Price.toFixed(2)}</p>
            </div>
            <button class="select-btn">Select plan</button>
            <ul class="features">
                <li><p>Auto Renewal: ${plan["Auto Renewal Allowed"]}</p></li>
                <li><p>Status: ${plan.Status}</p></li>
            </ul>
        </div>
    `;

    // Add event listener to the "Select plan" button
    const selectBtn = card.querySelector('.select-btn');
    selectBtn.addEventListener('click', () => {
        displaySelectedPlan(plan);
        openModal();
    });

    return card;
}

// Function to render all cards
function renderPlans(plansToRender) {
    plansContainer.innerHTML = '';
    plansToRender.forEach(plan => {
        const newCard = createCard(plan);
        plansContainer.appendChild(newCard);
    });
}

// Function to display an editable form for the selected plan in the modal
function displaySelectedPlan(plan) {
    modalPlanDetails.innerHTML = `
        ${lumenSvg}
        <form id="edit-form">
            <h2>Edit ${plan.Name}</h2>
            <p><strong>Product ID:</strong> ${plan["Product Id"]}</p>
            
            <p><strong>Price:</strong></p>
            <input type="number" id="price-input" value="${plan.Price}" step="0.01">
            
            <p><strong>Auto Renewal:</strong></p>
            <select id="renewal-select">
                <option value="Yes" ${plan["Auto Renewal Allowed"] === "Yes" ? "selected" : ""}>Yes</option>
                <option value="No" ${plan["Auto Renewal Allowed"] === "No" ? "selected" : ""}>No</option>
            </select>
            
            <p><strong>Status:</strong></p>
            <input type="text" id="status-input" value="${plan.Status}">
            
            <button type="submit">Update Plan</button>
        </form>
    `;

    const editForm = document.getElementById('edit-form');
    editForm.addEventListener('submit', (e) => {
        e.preventDefault();
        updatePlan(plan);
    });
}

// Function to handle the form submission and update the plan
function updatePlan(plan) {
    const priceInput = document.getElementById('price-input').value;
    const renewalSelect = document.getElementById('renewal-select').value;
    const statusInput = document.getElementById('status-input').value;

    // Update the original plan object in our data array
    plan.Price = parseFloat(priceInput);
    plan["Auto Renewal Allowed"] = renewalSelect;
    plan.Status = statusInput;

    // Re-render the cards to show the updated values
    renderPlans(allPlans);

    // Close the modal after updating
    closeModal();
}

// Event listeners for modal
closeModalBtn.addEventListener('click', closeModal);
window.addEventListener('click', (e) => {
    if (e.target === editModal) {
        closeModal();
    }
});

searchInput.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filteredPlans = allPlans.filter(plan =>
        plan.Name.toLowerCase().includes(searchTerm)
    );
    renderPlans(filteredPlans);
});

// Initial rendering of all plans
renderPlans(allPlans);